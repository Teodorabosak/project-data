import pandas as pd
import matplotlib.pyplot as plt 
import seaborn as sns

data = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\Median\MedianOrders.csv', sep=',',na_values=[''])  

data = data.drop(columns=['OrderID', 'id_customer', 'ship_mode', 'order_priority','order_date','shipping_date'])

matrix = data.corr(method='spearman').round(2) 

#data.heatmap(matrix, annot = True)

correlation_pairs = (
    matrix.unstack()
    .reset_index()
    .rename(columns={0: 'Correlation', 'level_0': 'Attribute1', 'level_1': 'Attribute2'}))

correlation_pairs = correlation_pairs[correlation_pairs['Attribute1'] != correlation_pairs['Attribute2']]
correlation_pairs = correlation_pairs.drop_duplicates(subset=['Correlation'])

# Find top 3 most and least correlated pairs
most_correlated = correlation_pairs.nlargest(3, 'Correlation')
least_correlated = correlation_pairs.nsmallest(3, 'Correlation')
result = pd.concat([most_correlated, least_correlated], keys=['Most Correlated', 'Least Correlated'])
result.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\CorrelationDf\correlation_results.csv', index=False)
plt.figure(figsize=(8, 6))

sns.heatmap(matrix, annot=True, cmap='coolwarm', fmt=".2f", cbar=True)
plt.title("Correlation Matrix")
plt.show()
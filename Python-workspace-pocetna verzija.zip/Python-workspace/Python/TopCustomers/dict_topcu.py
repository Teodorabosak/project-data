import pyodbc
import pandas as pd
conn = pyodbc.connect("Driver={ODBC Driver 18 for SQL Server};"
                      "Server=OMEGA-PC-10498;"  # 
                      "Database=Orders_Teodora;"     #
                      "Trusted_Connection=yes;"
                      "Encrypt=no;"
                      "TrustServerCertificate=yes;")



query = """
SELECT top 10 
    c.CustomerName,
    SUM(o.Sales) AS TotalSales
FROM Orders o join Customer c on (o.id_customer=c.RowID)
GROUP BY  CustomerName
ORDER BY TotalSales DESC
"""

# 
df = pd.read_sql(query, conn)

# Zatvori konekciju
conn.close()



# csv
df.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\TopCustomers\dict_topcu.csv', sep='|', index=False)
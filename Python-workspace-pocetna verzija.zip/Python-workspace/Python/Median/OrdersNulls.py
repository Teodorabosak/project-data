import pandas as pd

# Učitaj CSV fajl
df = pd.read_csv('Python\Read_data.csv\Orders.csv', sep=',',na_values=[''])  

# Prikaz broja `null` vrednosti po kolonama
print("Broj `null` vrednosti po kolonama:")
print(df.isnull().sum())

# Broj redova koji sadrže bar jednu `null` vrednost
rows_with_null = df.isnull().any(axis=1).sum() #axis jedan je row a 0 je kolujmn 
print(f"Broj redova koji sadrže `null` vrednosti: {rows_with_null}") #16

# Zameni `null` vrednosti medijanom po kolonama
df = df.fillna(df.median(numeric_only=True))




output_file = 'MedianOrders.csv'
df.to_csv(output_file, index=False)

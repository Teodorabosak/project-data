import pandas as pd


df1 = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\Median\MedianOrders.csv', sep=',')
df2 = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\DaysBetween\DaysBetween.csv', sep='|')


merged_df = pd.merge(df1, df2, on=['order_date', 'shipping_date'], how='inner')

merged_df = merged_df.drop_duplicates(subset=['order_date', 'shipping_date'])



merged_df.to_csv(r'Python/DaysBetween/WithDaysBetween.csv', sep='|', index=False)

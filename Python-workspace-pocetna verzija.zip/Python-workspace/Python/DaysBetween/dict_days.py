import pyodbc
import pandas as pd
conn = pyodbc.connect("Driver={ODBC Driver 18 for SQL Server};"
                      "Server=OMEGA-PC-10498;"  # 
                      "Database=Orders_Teodora;"     #
                      "Trusted_Connection=yes;"
                      "Encrypt=no;"
                      "TrustServerCertificate=yes;")



query = "SELECT order_date,shipping_date FROM Orders"

# 
df = pd.read_sql(query, conn)

# Zatvori konekciju
conn.close()


# u datetime format
df['order_date'] = pd.to_datetime(df['order_date'])
df['shipping_date'] = pd.to_datetime(df['shipping_date'])

# Računanje razlike
df['days_between'] = (df['shipping_date'] - df['order_date']).dt.days

# csv
df.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\DaysBetween\DaysBetween.csv', sep='|', index=False)
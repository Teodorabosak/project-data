import pyodbc

print(pyodbc.drivers())

import pandas as pd

# Konekcija sa SQL Server-om
conn = pyodbc.connect(
                    "Driver={ODBC Driver 18 for SQL Server};"
                    "Server=OMEGA-PC-10498;"  # ime svog servera
                    "Database=Orders_Teodora;"     # ime tvoje baze
                    "Trusted_Connection=yes;"
                    "Encrypt=no;"
                    "TrustServerCertificate=yes;")

print("Konekcija uspešna!")

# Unos podataka u tabelu Products
cursor = conn.cursor()





# Čitanje podataka iz SQL Server tabele "Customer"
query = "SELECT * FROM Customer"
df = pd.read_sql_query(query, conn)  # Direktno čitanje u pandas DataFrame

df.to_csv('Customer.csv', index=False)
# Prikaz podataka
print(df)


cursor.close()
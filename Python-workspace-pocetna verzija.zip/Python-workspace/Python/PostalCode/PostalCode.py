import pandas as pd

# Učitaj CSV fajl
df = pd.read_csv('Python\Read_data.csv\Orders.csv', sep=',') 

# Provera da li postoji kolona "Postal Code"
if 'id_location' in df.columns:
    # Formatira
     df['id_location'] = df['id_location'].fillna(0).astype(int).astype(str).str.zfill(5)

    
else:
    print("Kolona 'Postal Code' ne postoji u fajlu!")

# Prikaz DataFrame-a nakon formatiranja
print(df)


output_file = 'PostalCode.csv'
df.to_csv(output_file, index=False)

import pandas as pd

# Učitaj CSV fajl u DataFrame
file_path = r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\DaysBetween\WithDaysBetween.csv'
df = pd.read_csv(file_path, sep='|')  

#prosecvna vr mean, sum ukuona

pivot_order_priority = pd.pivot_table(
    df,
    values=['discount', 'shipping_cost', 'days_between', 'profit', 'sales'],
    index=['order_priority'],
    aggfunc={'discount': 'mean', 'shipping_cost': 'mean', 'days_between': 'mean', 'profit': 'sum', 'sales': 'sum'}
).round(2)

print(pivot_order_priority)
# csv
pivot_order_priority.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\PivotTables\pivot1.csv', sep='|', index=False)
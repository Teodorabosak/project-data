import pandas as pd


df1 = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\PivotTables\WithoutBetween.csv', sep='|')
df2 = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\DaysBetween\DaysBetween.csv', sep='|')


merged_df = pd.merge(df1, df2, on=['Order Date','Ship Date'], how='inner')

merged_df = merged_df.drop_duplicates(subset=['Order ID'])



merged_df.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\PivotTables\All.csv', sep='|', index=False)

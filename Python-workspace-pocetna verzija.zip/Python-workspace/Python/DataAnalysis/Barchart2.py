import pandas as pd
import matplotlib.pyplot as plt


file_path = r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\PivotTables\All.csv'
data = pd.read_csv(file_path, sep='|')


ndf = data['Product Sub-Category'].value_counts().rename_axis('Subcategory').reset_index(name='Orders')


labels1 = ndf['Subcategory']
values = ndf['Orders']


plt.figure(figsize=(10, 6)) #sam crtez je plot a ovo oko njega je figura i jedna figura moze imati vise crteza
plt.bar(labels1, values, color="Orange")


plt.xticks(rotation=45, ha='right')
#da bi se video tekst

plt.title('Orders per Product Sub-Category')
plt.xlabel('Subcategory')
plt.ylabel('Orders')

plt.tight_layout()
plt.show()

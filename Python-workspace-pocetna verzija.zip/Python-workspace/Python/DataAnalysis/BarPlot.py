import pandas as pd
import matplotlib.pyplot as plt

# Load the data
file_path = r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\PivotTables\All.csv'
df = pd.read_csv(file_path, sep='|')

# Group by 'id_region' and count the number of OrderIDs for each region
region_order_counts = df.groupby('Region')['Order ID'].count()

# Create the bar chart
fig, ax = plt.subplots()

ax.bar(region_order_counts.index, region_order_counts.values, color='red')

# label
ax.set_xlabel('Region')
ax.set_ylabel('Order Count')

# Title of the plot
ax.set_title('Order Count by Region')

#Conclusion: This bar chart helps to visualize how orders are distributed across different regions

# Show the plot
plt.show()

import pandas as pd
import matplotlib.pyplot as plt

# Load the data
file_path = r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\PivotTables\All.csv'
df = pd.read_csv(file_path, sep='|')

fig = plt.figure(figsize=(10,4))

plt.hist(df['Customer ID'], bins=1048, edgecolor='black')

plt.title("Orders by Customers")

plt.ylabel("Count of Order ID")
plt.show()
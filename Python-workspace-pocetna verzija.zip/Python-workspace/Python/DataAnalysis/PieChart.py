import pandas as pd
import matplotlib.pyplot as plt

file_path = r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\PivotTables\All.csv'
data = pd.read_csv(file_path, sep='|')


ndf = data['Product Category'].value_counts().rename_axis('Category').reset_index(name='Orders')
print(ndf.head)

labels1 = ndf.Category
values = ndf.Orders

fig = plt.figure()
ax = fig.add_axes([0,0,1,1])
ax.axis('equal')

ax.pie(values, labels = labels1, autopct = '%1.2f%%')
# Title of the plot
plt.show()
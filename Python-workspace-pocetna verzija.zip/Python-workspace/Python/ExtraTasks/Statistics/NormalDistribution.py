import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
import pandas as pd

# Učitaj CSV fajl u DataFrame
file_path = r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\PivotTables\All.csv'
df = pd.read_csv(file_path, sep='|')  

plt.figure(figsize=(12, 6))
regions = df['Region'].unique()  # svi regioni

for region in regions:
    region_data = df[df['Region'] == region]['Sales']  # Filtriraj podatke za region
    
    # mean and std
    mean_sales = region_data.mean()
    std_sales = region_data.std()
    
    # Generiši vrednosti za X (opseg podataka), od tri puta standardna devijacija levo od srednje vrednosti, do tri puta standardna devijacija desno (kako bi obuhvatili većinu podataka).
    x = np.linspace(mean_sales - 3 * std_sales, mean_sales + 3 * std_sales, 100)
    
    # Generiši normalnu distribuciju za dati region
    y = norm.pdf(x, mean_sales, std_sales)
    
    # Nacrtaj krivulju
    plt.plot(x, y, label=f'Region {region}')
    plt.fill_between(x, y, alpha=0.3)  # Popuni ispod krivulje

    # Ispiši srednju vrednost i standardnu devijaciju za region
    print(f"Region: {region}")
    print(f"  Srednja vrednost prodaje (mean): {mean_sales:.2f}") #format 
    print(f"  Standardna devijacija prodaje (std): {std_sales:.2f}")

# Dodaj oznake i naslov
plt.title('Normalna distribucija prodaje po regionima', fontsize=14)
plt.xlabel('Prodaja', fontsize=12)
plt.ylabel('Gustina', fontsize=12)
plt.legend(title="Regioni")
plt.show()

import scipy.stats as stats

# Funkcija za t-test između dva regiona, T-test se koristi za statističko upoređivanje srednjih vrednosti
#  između dva regiona kako bi se utvrdilo da li postoji značajna razlika između njihovih srednjih vrednosti prodaje.
def t_test_between_regions(region_1_data, region_2_data):
    t_stat, p_value = stats.ttest_ind(region_1_data, region_2_data)
    return p_value

# Listu svih regiona
regions = df['Region'].unique()

# Prolazimo kroz sve parove regiona i upoređujemo njihove p-vrednosti
for i in range(len(regions)):
    for j in range(i + 1, len(regions)):  # Upoređujemo samo parove
        region_1 = regions[i]
        region_2 = regions[j]
        
        # Podaci za oba regiona
        region_1_data = df[df['Region'] == region_1]['Sales']
        region_2_data = df[df['Region'] == region_2]['Sales']
        
        # T-test između ova dva regiona
        p_value = t_test_between_regions(region_1_data, region_2_data)
        
        # Ako je p-vrednost manja od 0.05, razlika je statistički značajna
        if p_value < 0.05:
            print(f"Statistički značajna razlika između regiona {region_1} i {region_2}: p-vrednost = {p_value:.5f}")
        else:
            print(f"Nema statistički značajne razlike između regiona {region_1} i {region_2}: p-vrednost = {p_value:.5f}")

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.animation import FuncAnimation
import calendar


def update_anim(week):
    top10= df_pivot[week].sort_values(ascending=False).head(10)

    ax.clear()
    colors = ['#FFA500', '#FFC100', '#FFD700']
    ax.barh(top10.index[:3], top10[:3], color=colors, height=0.7)
    ax.barh(top10.index[3:], top10[3:], color='#314960', height=0.7)

    ax.set_title(f" Profits in week {week} ", fontsize=16)
    ax.set_xlabel("Profits")
    ax.set_ylabel("Order Priority")
    ax.xaxis.set_major_formatter(ticker.StrMethodFormatter('${x:,.0f}'))  
    for i, (value, name) in enumerate(zip(top10, top10.index)):
        ax.text(value, i, f'{value:,.0f}', va='center', ha='left', color='black')

# Load the data
file_path = r'C:\Users\teodora.bosak\Desktop\Python-workspace\Python\PivotTables\All.csv'

df = pd.read_csv(file_path, sep='|', usecols=['Order Priority','Order Date','Profit'])

df['Order Date'] = pd.to_datetime(df['Order Date'])
df['Week'] = df['Order Date'].dt.isocalendar().week


df_pivot = df.pivot_table(
    index='Order Priority',
    columns='Week',
    values='Profit',
    aggfunc='sum'   
)

fig, ax = plt.subplots(figsize=(10,6))


print(list(df_pivot.columns))
animation = FuncAnimation(fig, update_anim, frames=df_pivot.columns, repeat=True, interval=1000)

plt.show()
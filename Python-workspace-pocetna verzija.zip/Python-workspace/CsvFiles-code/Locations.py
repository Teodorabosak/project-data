import pandas as pd
import glob

# Define the path to the CSV file
csv_files = glob.glob(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\*.csv')  # Učitaj sve CSV fajlove u folderu

all_data = []
for file in csv_files:
    df = pd.read_csv(file, sep='|')  # Učitaj CSV fajl
    all_data.append(df)  # Dodaj DataFrame u listu

combined_df = pd.concat(all_data, ignore_index=True)

# Izdvajanje željenih kolona
columns = combined_df[['Postal Code', 'Country', 'State or Province', 'City']]


# Uklanjanje duplikata u DataFrame-u
selected_columns = columns.drop_duplicates(subset=['Postal Code'])


selected_columns.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\LocationsImport', sep='|', index=False)

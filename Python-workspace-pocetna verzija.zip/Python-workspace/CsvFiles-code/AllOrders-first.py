import pandas as pd
import glob

# Define the path to the CSV file
csv_files = glob.glob(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\*.csv')
  # Učitaj sve CSV fajlove u folderu

all_data = []
for file in csv_files:
    df = pd.read_csv(file, sep='|')  # Učitaj CSV fajl, citamke prazne celije kao nan ove sa razmakom isto
    all_data.append(df)  # Dodaj DataFrame u listu

combined_df = pd.concat(all_data, ignore_index=True) #ista struktura spajaju se
combined_df = combined_df.where(pd.notnull(combined_df), None)


print("Broj `null` vrednosti po kolonama:")
print(combined_df.isnull().sum()) # Broj `null` vrednosti po kolonama


# Izdvajanje željenih kolona
columns = combined_df[['Order Priority','Discount','Unit Price','Shipping Cost','Customer ID','Ship Mode','Product Base Margin','Region','Postal Code','Order Date','Ship Date','Profit','Quantity ordered new','Sales','Order ID', 'Product Name']]

# Uklanjanje duplikata u DataFrame-u
selected_columns = columns.drop_duplicates(subset=['Order ID']) #kljuc

selected_columns.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\AllOrdersFirst.csv', sep='|', index=False)
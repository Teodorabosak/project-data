
import pandas as pd


df1 = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\AllOrdersFirst.csv', sep='|')
df2 = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\KeyRegion.csv', sep='|')


merged_df = pd.merge(df1, df2, on='Region', how='inner')


merged_df.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\OrdersSecondRegion.csv', sep='|', index=False)

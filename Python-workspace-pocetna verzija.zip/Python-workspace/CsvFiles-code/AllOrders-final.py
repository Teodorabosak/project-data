import pandas as pd

# Učitaj CSV fajl u DataFrame
file_path = r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\OrdersRegionProductID.csv'
df = pd.read_csv(file_path, sep='|', na_values=[' '])  # NaN za prazne vrednosti
print(df.columns)



#print("Broj `null` vrednosti po kolonama:")
#print(df.isnull().sum()) # Broj `null` vrednosti po kolonama

# Konvertujte datume u datetime format
#df['Order Date'] = pd.to_datetime(df['Order Date'], errors='coerce')
#df['Ship Date'] = pd.to_datetime(df['Ship Date'], errors='coerce')

df['Product Base Margin'] = df['Product Base Margin'].astype('float32')
df['Unit Price'] =df['Unit Price'].astype('float32')


columns = df[
    ['Order ID', 'Customer ID', 'Product Id', 'Region Id', 'Postal Code',
     'Shipping Cost', 'Ship Date', 'Order Date', 'Discount', 'Order Priority',
     'Profit', 'Quantity ordered new', 'Sales', 'Ship Mode', 'Product Base Margin', 'Unit Price']
]


# Uklanjanje duplikata u DataFrame-u
selected_columns = columns.drop_duplicates(subset=['Order ID']) #kljuc

print(df.dtypes)

output_path = r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\OrdersImport.csv'
selected_columns.to_csv(output_path, sep='|', index=False)

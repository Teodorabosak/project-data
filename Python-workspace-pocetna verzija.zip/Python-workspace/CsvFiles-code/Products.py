import pandas as pd
import glob

# Define the path to the CSV file
csv_files = glob.glob(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\*.csv')  # Učitaj sve CSV fajlove u folderu

all_data = []
for file in csv_files:
    df = pd.read_csv(file, sep='|')  # Učitaj CSV fajl
    all_data.append(df)  # Dodaj DataFrame u listu

combined_df = pd.concat(all_data, ignore_index=True)


subcategory_name_to_id = {
    "Office Furnishings": 1,
    "Chairs & Chairmats": 2,
    "Bookcases": 3,
    "Tables": 4,
    "Paper": 5,
    "Rubber Bands": 6,
    "Envelopes": 7,
    "Scissors, Rulers and Trimmers": 8,
    "Binders and Binder Accessories": 9,
    "Labels": 10,
    "Storage & Organization": 11,
    "Computer Peripherals": 12,
    "Telephones and Communication": 13,
    "Office Machines": 14,
    "Copiers and Fax": 15,
    "Appliances": 16,
    "Pens & Art Supplies": 17 
}

# Zamenjujemo tekstualne vrednosti podkategorije sa ID vrednostima
combined_df['Product Sub-Category'] = combined_df['Product Sub-Category'].map(subcategory_name_to_id).astype('int32')

# Izdvajanje željenih kolona
columns = combined_df[['Product Name', 'Product Container', 'Product Sub-Category']]

# Uklanjanje duplikata u DataFrame-u
selected_columns = columns.drop_duplicates(subset=['Product Name'])


selected_columns.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\ProductsImport', sep='|', index=False)

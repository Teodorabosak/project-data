import pyodbc
import pandas as pd

conn = pyodbc.connect("Driver={ODBC Driver 18 for SQL Server};"
                      "Server=OMEGA-PC-10498;"  # 
                      "Database=Orders_Teodora;"     #
                      "Trusted_Connection=yes;"
                      "Encrypt=no;"
                      "TrustServerCertificate=yes;")



query = "SELECT RowID, ProductName FROM Products"

# Učitaj podatke u pandas DataFrame
df = pd.read_sql(query, conn)

# Zatvori konekciju
conn.close()

# Spremi podatke u CSV fajl
df.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\KeyProduct', sep='|', index=False)
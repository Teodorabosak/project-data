
import pandas as pd


df1 = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\OrdersSecondRegion.csv', sep='|')
df2 = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\KeyProduct.csv', sep='|')


merged_df = pd.merge(df1, df2, on='Product Name', how='inner')


merged_df.to_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\OrdersRegionProductID.csv', sep='|', index=False)

import pyodbc

print(pyodbc.drivers())

import pandas as pd

# Učitaj podatke iz CSV fajla
df = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\Internship\Returns.csv', sep='|')


# Konekcija sa SQL Server-om
conn = pyodbc.connect(
                    "Driver={ODBC Driver 18 for SQL Server};"
                    "Server=OMEGA-PC-10498;"  # ime svog servera
                    "Database=Orders_Teodora;"     # ime tvoje baze
                    "Trusted_Connection=yes;"
                    "Encrypt=no;"
                    "TrustServerCertificate=yes;")

print("Konekcija uspešna!")

# Unos podataka u tabelu Products
cursor = conn.cursor()

# Unos podataka u tabelu Products
cursor = conn.cursor() #

for index, row in df.iterrows():
    cursor.execute("""
        INSERT INTO Returned (id_order, status_o)
        VALUES (?, ?)""",
        row['Order ID'],  # kolone iz CSV-a
        row['Status']    
    )


conn.commit()
cursor.close()

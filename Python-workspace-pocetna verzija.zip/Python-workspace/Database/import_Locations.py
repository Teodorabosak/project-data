import pyodbc

print(pyodbc.drivers())

import pandas as pd

# Učitaj podatke iz CSV fajla
products_df = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\LocationsImport.csv', sep='|')


# Konekcija sa SQL Server-om
conn = pyodbc.connect(
                    "Driver={ODBC Driver 18 for SQL Server};"
                    "Server=OMEGA-PC-10498;"  # ime svog servera
                    "Database=Orders_Teodora;"     # ime tvoje baze
                    "Trusted_Connection=yes;"
                    "Encrypt=no;"
                    "TrustServerCertificate=yes;")

print("Konekcija uspešna!")

# Unos podataka u tabelu 
cursor = conn.cursor()



for index, row in products_df.iterrows():
    cursor.execute("""
        INSERT INTO Locations (PostalCode, Country, StateOrProvince, City)
        VALUES (?, ?, ?, ?)""",
        row['Postal Code'],  # iz CSV
        row['Country'],  
        row['State or Province'], 
        row['City']
    )



conn.commit()
cursor.close()
import pyodbc

print(pyodbc.drivers())

import pandas as pd

# Učitaj podatke iz CSV fajla
df = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\OrdersSaNull.csv', sep='|')

# Pretvaranje praznih stringova u NaN (podrazumevane null vrednosti u Pandas-u)
df.replace(r'^\s*$', None, regex=True, inplace=True)  # Zamenjuje prazne vrednosti sa None (ekvivalentno NaN)



# Konekcija sa SQL Server-om
conn = pyodbc.connect(
                    "Driver={ODBC Driver 18 for SQL Server};"
                    "Server=OMEGA-PC-10498;"  # ime svog servera
                    "Database=Orders_Teodora;"     # ime tvoje baze
                    "Trusted_Connection=yes;"
                    "Encrypt=no;"
                    "TrustServerCertificate=yes;")

print("Konekcija uspešna!")

# Unos podataka u tabelu Products
cursor = conn.cursor()

for index, row in df.iterrows():
    try:
        cursor.execute("""
            INSERT INTO Orders (
                       OrderID, id_customer, id_product, id_region, id_location, 
                       product_base_margin, unit_price,
                       shipping_cost, shipping_date, discount, order_priority, profit, quantity, sales, order_date, ship_mode)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
    
            row['Order ID'],
            row['Customer ID'],  
            row['Product Id'], 
            row['Region Id'],
            row['Postal Code'], 
            row['Product Base Margin'], 
            row['Unit Price'],
            row['Shipping Cost'], 
            row['Ship Date'],  # 
            row['Discount'],  
            row['Order Priority'], 
            row['Profit'],
            row['Quantity ordered new'],  
            row['Sales'], 
            row['Order Date'],  #
            row['Ship Mode']
        )
    except Exception as e:
        print(f"Greška pri unosu u red {index}: {e}")
        print(f"Podaci u tom redu: {row}")
        break  # Prekida petlju da bi stekli uvid u problematičan red



conn.commit()
cursor.close()
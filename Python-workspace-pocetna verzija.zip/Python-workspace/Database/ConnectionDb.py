import pyodbc #biblioteke pip install

class Database:
#bulk insert csv fajlova u tabele
    def bulk_insert(data_file, target_table): #fieldterminator je delimeter
         sql = f"""
                bulk insert {target_table}
                from '{data_file}'
                with 
                (
                format='csv',
                firstrow = 2,
                fieldterminator = '|', 
                rowterminator ='\\n'
                )
            """.strip()
         return sql
    

#promenljive 

    driver='ODBC Driver 18 for SQL Server'
    server='OMEGA-PC-10498'
    database='Orders_Teodora'

    def __init__(self ): #
         self.conn = pyodbc.connect(
            f"Driver={{{self.driver}}};"
            f"Server={self.server};"
            f"Database={self.database};"
            "Trusted_Connection=yes;"
            "Encrypt=no;"
            "TrustServerCertificate=yes;"
        )
    print("Konekcija uspešna!")
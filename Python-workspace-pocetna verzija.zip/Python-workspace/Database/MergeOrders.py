import os 
import pandas as pd #pip inst pandas

master_df = pd.DataFrame()

for file in os.listdir(os.getcwd(), 'OrdersByRegions'):
    if file.endswith('.csv'):
        master_df=master_df.append(pd.read_csv(file))
        print()

master_df.to_csv('Master Orders.csv', index= False)
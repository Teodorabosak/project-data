import pyodbc

print(pyodbc.drivers())

import pandas as pd

# Učitaj podatke iz CSV fajla
products_df = pd.read_csv(r'C:\Users\teodora.bosak\Desktop\Python-workspace\CsvFiles\Merged\ProductsImport.csv', sep='|')


# Konekcija sa SQL Server-om
conn = pyodbc.connect(
                    "Driver={ODBC Driver 18 for SQL Server};"
                    "Server=OMEGA-PC-10498;"  # ime svog servera
                    "Database=Orders_Teodora;"     # ime tvoje baze
                    "Trusted_Connection=yes;"
                    "Encrypt=no;"
                    "TrustServerCertificate=yes;")

print("Konekcija uspešna!")

# Unos podataka u tabelu Products
cursor = conn.cursor()


for index, row in products_df.iterrows():
    cursor.execute("""
        INSERT INTO Products (ProductName, ProductContainer, Subcategory)
        VALUES (?, ?, ?)""",
        row['Product Name'],  # Ime proizvoda iz CSV
        row['Product Container'],  # Kontejner proizvoda
        row['Product Sub-Category'],  # ID podkategorije
        
    )



conn.commit()
cursor.close()